====================== Google Translated Pokémon Emerald ======================

By: Simply BLG, 2022-06-25
simplyblgdev.github.io

Contact:
simplyblgdev@gmail.com

1. INSTALLATION

Patch your Pokèmon Emerald English ROM (sha1: f3ae088181bf583e55daf962a92bb46f4f1d07b7)
with Lunar IPS using the provided patch file.

2. DETAILS

Translation sequence:
English -> Russian -> Spanish -> Japanese -> Finnish -> Arabic -> Corsican -> Chinese (Simplified) -> English

Text translated:
Ability names
Ability descriptions
Natures
Type names
Move names
Move descriptions
Pokémon names
Pokémon Pokédex descriptions
Battle text
Options menu
Choice menus
Start menu
Dialog text
Match call messages
Trainer classes
Trainer names
Item names
Item descriptions
Credits
Miscellaneous text
